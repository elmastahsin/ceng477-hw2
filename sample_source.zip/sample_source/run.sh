#!/bin/bash
# filepath: /Users/tahsin/Desktop/ceng477-hw2/sample_source/run.sh

# Renk kodları
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Çıktı klasörü
OUTPUT_DIR="my_outputs"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}   Rasterizer Build & Test Script${NC}"
echo -e "${BLUE}========================================${NC}"

# Çıktı klasörünü oluştur
mkdir -p "$OUTPUT_DIR"

# Build
echo -e "\n${YELLOW}[BUILD] Derleniyor...${NC}"
make clean
make

if [ $? -ne 0 ]; then
    echo -e "${RED}[HATA] Derleme başarısız!${NC}"
    exit 1
fi

echo -e "${GREEN}[BUILD] Derleme başarılı!${NC}\n"

# Input klasörleri
INPUT_DIRS=(
    "inputs_outputs/culling_disabled_inputs"
    "inputs_outputs/culling_enabled_inputs"
    "inputs_outputs/clipping_example"
    "inputs_outputs/different_projection_type"
)

# Her klasördeki XML dosyalarını çalıştır
for dir in "${INPUT_DIRS[@]}"; do
    if [ -d "$dir" ]; then
        echo -e "${BLUE}----------------------------------------${NC}"
        echo -e "${BLUE}Klasör: $dir${NC}"
        echo -e "${BLUE}----------------------------------------${NC}"
        
        for xml_file in "$dir"/*.xml; do
            if [ -f "$xml_file" ]; then
                filename=$(basename "$xml_file")
                echo -e "${YELLOW}[ÇALIŞTIRILIYOR] $filename${NC}"
                ./rasterizer "$xml_file"
                
                if [ $? -eq 0 ]; then
                    echo -e "${GREEN}[TAMAM] $filename${NC}"
                else
                    echo -e "${RED}[HATA] $filename${NC}"
                fi
            fi
        done
        echo ""
    fi
done

# Oluşan PPM dosyalarını çıktı klasörüne taşı
echo -e "${YELLOW}[TAŞINIYOR] PPM dosyaları $OUTPUT_DIR klasörüne taşınıyor...${NC}"
mv *.ppm "$OUTPUT_DIR/" 2>/dev/null

if [ $? -eq 0 ]; then
    echo -e "${GREEN}[TAMAM] Çıktılar $OUTPUT_DIR/ klasörüne kaydedildi${NC}"
else
    echo -e "${YELLOW}[UYARI] Taşınacak PPM dosyası bulunamadı${NC}"
fi

echo -e "\n${BLUE}========================================${NC}"
echo -e "${GREEN}   Tüm testler tamamlandı!${NC}"
echo -e "${BLUE}========================================${NC}"

# Çıktı klasöründeki dosyaları listele
echo -e "\n${BLUE}Oluşturulan çıktılar:${NC}"
ls -la "$OUTPUT_DIR"/*.ppm 2>/dev/null